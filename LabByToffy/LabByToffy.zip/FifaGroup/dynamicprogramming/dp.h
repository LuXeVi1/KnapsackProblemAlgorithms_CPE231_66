#ifndef DP_H
#define DP_H

#include <stdio.h>
#include <stdlib.h>
#include "../structure.h"

int dynamic_programming(int n, int maxWeight, Product products[]);
// void solve_dynamic_programming(int n, int maxWeight, Product products[]);

#endif //DP_H
