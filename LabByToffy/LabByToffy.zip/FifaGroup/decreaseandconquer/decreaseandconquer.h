#ifndef DECREASEANDCONQUER_H
#define DECREASEANDCONQUER_H

#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include "../structure.h"
#include "../divideandconquer/divideandconquer.h"

int decreaseAndConquerKnapsack(int n, int maxWeight, Product* products);

#endif // DECREASEANDCONQUER_H
