#ifndef BRUTEFORCE_H
#define BRUTEFORCE_H

#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include "../structure.h"

int bruteforceKnapsack(int n, int maxWeight, Product* products);

#endif // BRUTEFORCE_H
