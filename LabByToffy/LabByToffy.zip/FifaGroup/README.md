# CPE231 FinalProject
## Project Overall
- Implement the algorithms you have learned in class(including genetic algorithm)
- Compare the result in each algorithms using the criteria as your design
## Test Case
- have already set what’s input to your program(problem instance)
`Number of items : 25, 50, 100, 500, 1000`
Link : `https://github.com/KittpongT/knapsackProblem`
- We need to pass all threshold answer in each instanceTry our best (TA did not provide the threshold answer to us)
