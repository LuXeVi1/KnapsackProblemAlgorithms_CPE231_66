#ifndef SATTO_H
#define SATTO_H

#include <stdio.h>
#include <stdlib.h>
#include "../structure.h"

int SaTToknapsack(int n, int capacity, Product *products);
// void solve_dynamic_programming(int n, int maxWeight, Product products[]);

#endif //SATTO_H
