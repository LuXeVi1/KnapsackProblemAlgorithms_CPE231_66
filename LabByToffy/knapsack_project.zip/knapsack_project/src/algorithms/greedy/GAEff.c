#include "GAEff.h"
#include "geneticUtils.h"
#include <stdlib.h>
#include <time.h>

/**
 * Initializes a population with random solutions (chromosomes).
 * @param population Pointer to the population array.
 * @param populationSize The number of individuals in the population.
 * @param size Number of items in the knapsack.
 */
void initializePopulation(Population *population, int populationSize, int size) {
    srand(time(NULL));  // Initialize random number generator

    population->individuals = (Individual *)malloc(populationSize * sizeof(Individual));
    population->size = populationSize;

    for (int i = 0; i < populationSize; i++) {
        population->individuals[i].genes = (bool *)malloc(size * sizeof(bool));

        for (int j = 0; j < size; j++) {
            population->individuals[i].genes[j] = rand() % 2; // Randomly initialize genes (0 or 1)
        }

        // Evaluate fitness for the individual
        evaluateFitness(&population->individuals[i], size);
    }
}

/**
 * Runs the Genetic Algorithm to solve the Knapsack Problem.
 * @param items Array of items.
 * @param size Number of items.
 * @param maxWeight Maximum allowable weight.
 * @param populationSize Size of the population.
 * @param generations Number of generations to run.
 * @return The best solution found.
 */
Solution runGeneticAlgorithm(const Item items[], int size, int maxWeight, int populationSize, int generations) {
    Population population;
    initializePopulation(&population, populationSize, size);

    // Run for the given number of generations
    for (int gen = 0; gen < generations; gen++) {
        // Selection: Tournament or Roulette (can be customized)
        selectParents(&population);

        // Crossover: Generate offspring
        crossover(&population, size);

        // Mutation: Apply mutation to offspring
        mutate(&population, size);

        // Evaluate fitness of new population
        for (int i = 0; i < populationSize; i++) {
            evaluateFitness(&population.individuals[i], size);
        }
    }

    // Find the best solution in the population
    Individual *bestIndividual = getBestIndividual(&population);

    Solution bestSolution = { .totalValue = bestIndividual->fitness, .totalWeight = 0 };
    for (int i = 0; i < size; i++) {
        if (bestIndividual->genes[i]) {
            bestSolution.totalWeight += items[i].weight;
        }
    }

    // Cleanup memory
    free(population.individuals);
    
    return bestSolution;
}
