#include "geneticUtils.h"
#include <stdlib.h>
#include <time.h>

/**
 * Evaluates the fitness of an individual.
 * Fitness is the total value of the items included in the knapsack.
 * @param individual Pointer to the individual to evaluate.
 * @param size Number of items.
 */
void evaluateFitness(Individual *individual, int size) {
    individual->fitness = 0;
    individual->weight = 0;

    for (int i = 0; i < size; i++) {
        if (individual->genes[i]) {
            individual->fitness += items[i].value;
            individual->weight += items[i].weight;
        }
    }

    // Penalize if weight exceeds maximum limit
    if (individual->weight > MAX_WEIGHT) {
        individual->fitness = 0;
    }
}

/**
 * Selects parents from the population using tournament selection.
 * @param population Pointer to the population.
 */
void selectParents(Population *population) {
    // Implement tournament selection or roulette selection
}

/**
 * Performs crossover between selected parents to generate offspring.
 * @param population Pointer to the population.
 * @param size Number of items.
 */
void crossover(Population *population, int size) {
    // Perform crossover to create new individuals
}

/**
 * Applies mutation to the population.
 * @param population Pointer to the population.
 * @param size Number of items.
 */
void mutate(Population *population, int size) {
    // Apply mutation by flipping bits randomly
}

/**
 * Returns the best individual in the population.
 * @param population Pointer to the population.
 * @return The best individual.
 */
Individual* getBestIndividual(Population *population) {
    Individual *best = &population->individuals[0];
    for (int i = 1; i < population->size; i++) {
        if (population->individuals[i].fitness > best->fitness) {
            best = &population->individuals[i];
        }
    }
    return best;
}
