#ifndef GENETIC_H
#define GENETIC_H

#include "../src/structure.h"  

// Function prototypes for genetic algorithms

/**
 * Runs a genetic algorithm to solve the optimization problem.
 * @param items Array of items to process.
 * @param size Number of items in the array.
 * @param maxWeight Maximum allowable weight.
 * @return Solution struct containing the best result.
 */
Solution runGeneticAlgorithm(const Item items[], int size, int maxWeight);

#endif // GENETIC_H
